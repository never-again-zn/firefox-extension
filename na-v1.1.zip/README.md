# Never Again

A browser extension that highlights the products and brands related to apartheid Israel.

The extension literally highlights the name of the brand, product or company on a web page. When you hover over the highlight, you are presented with an abbreviated description of the offense and a link to additional information.

## Website

[never-aga.in](https://never-aga.in)
